const responseObj = {
    hello:"www.google.com",
    hey: "Hey! What's Up",
    bp:"High/low",
    high:"TAke Deep Breath",
    low:"Coffee...",
    sugar:"high/low",
    today: new Date().toDateString(),
    time: new Date().toLocaleTimeString(),
  };