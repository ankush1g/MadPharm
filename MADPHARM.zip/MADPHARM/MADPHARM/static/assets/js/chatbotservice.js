const responseObj = {
    hello: "www.google.com",
    hey: "Hey! What's Up",
    bp:"High/low",
    high:"TAke Deep Breath",
    low:"take-Coffee...",
    sugar:"high/low",
    today: new Date().toDateString(),
    time: new Date().toLocaleTimeString(),
  };
  // const fetchResponse=(userInput)=>{
  //   return responseObj[userInput];
  // }
  // const chatbotservice={
  //   getBotResponse(userInput){
  //      return fetchResponse(userInput);
  //   }
  // }
  // export default chatbotservice;
